package javacafe;

public class Staff {
    
    protected Menu[] orderList = new Menu[50]; //Declare an Array of Objects (Type Menu) (Not create object yet)
}
